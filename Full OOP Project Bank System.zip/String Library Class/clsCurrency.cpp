#include "clsCurrency.h"
