// Global.cpp
#include "Global.h"

clsUser CurrentUser = clsUser::Find("", "");  // Definition and initialization