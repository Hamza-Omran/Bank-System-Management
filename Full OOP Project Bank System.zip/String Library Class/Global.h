// Global.h
#pragma once
#include <iostream>
#include "clsUser.h"

extern clsUser CurrentUser;  // Declaration only