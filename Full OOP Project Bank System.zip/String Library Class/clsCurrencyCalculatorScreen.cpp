#include "clsCurrencyCalculatorScreen.h"
